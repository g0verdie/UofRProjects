Dan Scarafoni
dscarafo@u.rochester.edu
csc 173
prolog week one

manifest
	test.pl- contains all prolog programming files for the assignment
		functions
			shuffle- for part 1.2, shuffles two lists together 				into a third list
			backwards- my homemade function for part 1.3, checks 				if two lists are reverses of each other
			backwards2- the professor's version of the above.

	writeup- a pdf writeup report that contains all results and 				conclusions of tests on runtime as well as an analysis of the 			project

to run
	from a prolog command prompt- [test]
	shuffle(List1,List2,Final).
		List1 and List2 are the two lists to be shuffled
		Final is the list into which they are shuffled
	backwards(List1,List2).
		List1 and List2 are the two lists to be compared
	backwards2(List1,List2).
		List1 and List2 are the two lists to be compared