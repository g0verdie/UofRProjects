/**********************************************************************
    Java parser and pretty-printer.
 **********************************************************************/

#ifndef _PARSER_H
#define _PARSER_H

#include "scanner.h"

void parse();

#endif
