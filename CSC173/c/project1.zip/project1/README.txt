This project is the modified matrix code from the website

alterations-

	1. file reading function
		this will read a matrix from a file if it is written in the following format
				int rows
				int columns
				(matrix values at corresponding positions, all doubles)
				
	2: addition function
		this will add 2 matricies together, placing the answer into a third matrix. A display an error 
		message will be returned if any of the matricies are not the same size
	
	3: multiplication- 
		multiplies two matricies, placing the answer into a third matrix. If any of the matricies are of an innapropriate
		size an error message.
		
	4. transposition-
		This function transposes a matrix into a target matrix. If target matrix's dimensions are innapropriate, an error message
		will be sent.
		
The driver program contains several lines demonstrating these functions, as well as an example of deleting a matrix after formation.
		